//
//  PhotoCollectionViewCell.swift
//  PhotoCollection
//
//  Created by Spencer Curtis on 8/2/18.
//  Copyright © 2018 Lambda School. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {

    let myImageView = UIImageView()
    var photo: Photo?
    
    func updateViews() {
        
    }
    
    let title = UILabel()
    
    let collectionViewCellConstraints = [
        
        NSLayoutConstraint(item: myImageView, attribute: .leading, relatedBy: .equal, toItem: UICollectionViewCell, attribute: .leading, multiplier: 1.0, constant: 10.0),
        NSLayoutConstraint(item: myImageView, attribute: .centerY, relatedBy: .equal, toItem: UICollectionViewCell, attribute: .centerY, multiplier: 1.0, constant: 10.0),
        NSLayoutConstraint(item: myImageView, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 100.0),
        NSLayoutConstraint(item: myImageView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 100.0)
    ]
    
    func setUpSubViews() {
        
    }
    
}
